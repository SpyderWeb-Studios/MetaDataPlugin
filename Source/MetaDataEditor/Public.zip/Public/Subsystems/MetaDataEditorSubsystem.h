// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "MetaDataEditorSubsystem.generated.h"

/**
 * 
 */
UCLASS()
class METADATAEDITOR_API UMetaDataEditorSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()
	
public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

private:
	// The delegate hook
	void OnPreSavePackage(UPackage* Package, FObjectPreSaveContext Context);

	// Your actual automation logic
	void ExtractAndBakeMetadata(UStaticMesh* MeshAsset);
};
