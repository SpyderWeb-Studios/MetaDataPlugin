// Fill out your copyright notice in the Description page of Project Settings.


#include "Subsystems/MetaDataEditorSubsystem.h"

#include "InstancedStruct.h"
#include "Interfaces/MetaDataExportInterface.h"
#include "Libraries/FMetaDataRegistryItem.h"
#include "UObject/ObjectSaveContext.h"


void UMetaDataEditorSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	// Bind to the UE5 global save delegate
	UPackage::PreSavePackageWithContextEvent.AddUObject(this, &UMetaDataEditorSubsystem::OnPreSavePackage);

}

void UMetaDataEditorSubsystem::Deinitialize()
{
    UPackage::PreSavePackageWithContextEvent.RemoveAll(this);
	Super::Deinitialize();
}

void UMetaDataEditorSubsystem::OnPreSavePackage(UPackage* Package, FObjectPreSaveContext Context)
{
	// Ignore autosaves or cooking saves to prevent infinite loops
	if (Context.IsProceduralSave() || Context.IsCooking()) return;

	if (!Package) return;

	// Check if the package being saved contains a Static Mesh or Skeletal Mesh
	TArray<UObject*> ObjectsInPackage;
	GetObjectsWithOuter(Package, ObjectsInPackage, false);

	for (UObject* Obj : ObjectsInPackage)
	{
		UStaticMesh* Mesh = Cast<UStaticMesh>(Obj);
		if (Mesh)
		{
			ExtractAndBakeMetadata(Mesh);
		}
	}

	// Cleanup pass:
	UDataTable* RegistryTable = LoadObject<UDataTable>(nullptr, TEXT("/Game/Data/DT/DataRegistries/HexagonComponents/DT_StaticMeshMetadata.DT_StaticMeshMetadata"));
	if (!RegistryTable) return;
	TArray<FName> AllRowNames = RegistryTable->GetRowNames();
	bool bDidModify = false;

	for (const FName& RowName : AllRowNames)
	{
		FSoftObjectPath AssetPath(RowName.ToString());

		// 2. Verify if the asset still exists in the project
		// ResolveObject() returns nullptr if the asset cannot be found at that path
		if (AssetPath.ResolveObject() == nullptr)
		{
			// 3. Asset is gone, remove the row
			RegistryTable->RemoveRow(RowName);
			bDidModify = true;
			UE_LOG(LogTemp, Warning, TEXT("Cleaned up stale metadata row: %s - Asset is gone"), *RowName.ToString());
		}

		if (FMetaDataRegistryItem* ExistingRow = RegistryTable->FindRow<FMetaDataRegistryItem>(RowName, TEXT("Checking if it should be cleaned")))
		{
			// By assigning ExistingRow to NewRow, we are effectively working with the current state.
			// Clearing the array ensures we don't duplicate or keep old traits.

			if(ExistingRow->ExtractedTraits.IsEmpty())
			{
				RegistryTable->RemoveRow(RowName);
				bDidModify = true;
				UE_LOG(LogTemp, Warning, TEXT("Cleaned up stale metadata row: %s - No MetaData entries"), *RowName.ToString());
			}

		}
	}

	// 4. Mark dirty only if changes were made
	if (bDidModify)
	{
		RegistryTable->MarkPackageDirty();
	}
}

void UMetaDataEditorSubsystem::ExtractAndBakeMetadata(UStaticMesh* MeshAsset)
{
	
	if (!MeshAsset) return;

	UE_LOG(LogTemp, Display, TEXT("Extracting data from [%s]"), *GetNameSafe(MeshAsset));
    TArray<TInstancedStruct<FMetaDataTrait_Base>> SourceTraits;
	
    // Extract meta data from user asset data
    for (UAssetUserData* UserData : *MeshAsset->GetAssetUserDataArray())
    {
        if (UserData && UserData->Implements<UMetaDataExportInterface>())
        {
            IMetaDataExportInterface::Execute_ExportTraits(UserData, SourceTraits, false);
        }
    }

	UE_LOG(LogTemp, Display, TEXT("Found [%d] Traits to add to data registry"), SourceTraits.Num());

    // 2. Load/Open your Data Table
    UDataTable* RegistryTable = LoadObject<UDataTable>(nullptr, TEXT("/Game/Data/DT/DataRegistries/HexagonComponents/DT_StaticMeshMetadata.DT_StaticMeshMetadata"));
    if (!RegistryTable) return;

    // Use the Mesh Path as the Row Name (as per your requested architecture)
	const FName RowName = FName(*MeshAsset->GetPathName());

    // 3. Update the row
    FMetaDataRegistryItem NewRow;
	// Instead of always adding a new row, fetch the existing one if it exists!
	if (FMetaDataRegistryItem* ExistingRow = RegistryTable->FindRow<FMetaDataRegistryItem>(RowName, TEXT("")))
	{
		// By assigning ExistingRow to NewRow, we are effectively working with the current state.
		// Clearing the array ensures we don't duplicate or keep old traits.
		NewRow = *ExistingRow;
		NewRow.ExtractedTraits.Empty(); 
	}

	
	NewRow.ExtractedTraits.Reserve(SourceTraits.Num());

    for (TInstancedStruct<FMetaDataTrait_Base> Trait : SourceTraits)
    {
    	UE_LOG(LogTemp, Display, TEXT("Attempting to add [%s] to Extracted Traits"), *Trait.Get<FMetaDataTrait_Base>().ToString());
        if (Trait.IsValid())
        {
        	UE_LOG(LogTemp, Display, TEXT("Adding [%s] to Extracted Traits"), *Trait.Get<FMetaDataTrait_Base>().ToString());
            // Copy over the instanced struct
        	NewRow.ExtractedTraits.Add(Trait);
        }
    }
	
    // Add or Update the row in the table
    RegistryTable->AddRow(RowName, NewRow);
	UE_LOG(LogTemp, Display, TEXT("Added [%d] Traits to add to data registry"), NewRow.ExtractedTraits.Num());

    // 4. Mark dirty to ensure it saves
    RegistryTable->MarkPackageDirty();
    
	UE_LOG(LogTemp, Display, TEXT("Baked [%d] traits to row [%s] in Data Table."), NewRow.ExtractedTraits.Num(), *RowName.ToString());

}
